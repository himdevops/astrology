"""
schemas.py — Pydantic Schemas for Financial Astrology Engine
"""
from typing import List, Optional
from pydantic import BaseModel, Field


# ─────────────────────────────────────────────────────────────
# Input Schemas
# ─────────────────────────────────────────────────────────────

class BirthInput(BaseModel):
    name: str            = Field(...,              example="Himanshu")
    date: str            = Field(...,              example="1990-01-15")
    time: str            = Field(...,              example="10:30")
    place: str           = Field(...,              example="Mumbai, Maharashtra, India")
    latitude:            Optional[float] = Field(default=None, example=19.0760)
    longitude:           Optional[float] = Field(default=None, example=72.8777)
    timezone_offset_minutes: Optional[int] = Field(default=None, example=330)
    ayanamsa: str        = Field(default="lahiri", example="lahiri")


class TransitInput(BaseModel):
    date: str  = Field(...,              example="2026-04-15")
    time: str  = Field(default="09:15",  example="09:15")
    place: str = Field(default="Mumbai, Maharashtra, India")
    latitude:   Optional[float] = Field(default=None)
    longitude:  Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")


class DashaInput(BaseModel):
    """Input for Vimshottari Dasha calculation (requires birth chart)."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")
    as_of_date: Optional[str] = Field(
        default=None,
        example="2026-04-15",
        description="Date to find current dasha (defaults to today)"
    )
    years_to_show: int = Field(default=120, ge=10, le=120)


class DivisionalInput(BaseModel):
    """Input for divisional chart calculation."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")
    charts: List[str] = Field(
        default=["D2", "D9", "D10"],
        example=["D2", "D9", "D10"],
        description="Which divisional charts to compute: D2, D3, D9, D10"
    )


class SarvatobhadraInput(BirthInput):
    """Input for Sarvatobhadra Chakra casting with full transit analysis."""
    # Optional transit date for Vedha/Latta analysis
    # If omitted, today's planetary positions are used
    transit_date: Optional[str] = Field(
        default=None,
        example="2026-04-15",
        description="Date for transit SBC analysis. Defaults to today."
    )
    transit_time: Optional[str] = Field(
        default="09:15",
        example="09:15",
        description="Time for transit planets (IST). Defaults to 09:15 (NSE open)."
    )
    transit_place: Optional[str] = Field(
        default="Mumbai, Maharashtra, India",
        description="Location for transit planet calculation."
    )


class AshtakavargaInput(BaseModel):
    """Input for Ashtakavarga + transit date prediction."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")
    # Transit prediction settings
    transit_from_date: Optional[str] = Field(
        default=None,
        example="2026-04-15",
        description="Start date for transit predictions (default: today)"
    )
    days_ahead: int = Field(default=180, ge=30, le=365)


class YogaInput(BaseModel):
    """Input for yoga detection."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")


class TransitAlertInput(BaseModel):
    """Input for transit alert generation."""
    date: str  = Field(...,  example="2026-04-15")
    time: str  = Field(default="09:15", example="09:15")
    place: str = Field(default="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")
    days_ahead: int = Field(default=90, ge=7, le=365)
    # Optional natal chart for personal transit analysis
    natal_date:  Optional[str] = Field(default=None, example="1990-01-15")
    natal_time:  Optional[str] = Field(default=None, example="10:30")
    natal_place: Optional[str] = Field(default=None, example="Mumbai, Maharashtra, India")


class FullPredictionInput(BaseModel):
    """
    Full autonomous prediction — combines natal chart + current transits.
    If no natal chart provided, uses transits only.
    """
    # Current date/transit
    transit_date: str  = Field(...,  example="2026-04-15")
    transit_time: str  = Field(default="09:15")
    transit_place: str = Field(default="Mumbai, Maharashtra, India")
    transit_latitude:  Optional[float] = Field(default=None)
    transit_longitude: Optional[float] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")
    days_ahead: int = Field(default=90, ge=7, le=365)

    # Optional: natal chart for personalized prediction
    natal_name:  Optional[str]  = Field(default=None)
    natal_date:  Optional[str]  = Field(default=None)
    natal_time:  Optional[str]  = Field(default=None)
    natal_place: Optional[str]  = Field(default=None)
    natal_latitude:  Optional[float] = Field(default=None)
    natal_longitude: Optional[float] = Field(default=None)


class StrengthCalendarInput(BaseModel):
    """Input for Ashtakavarga daily/monthly/yearly strength calendar."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")
    
    # Calendar type
    calendar_type: str = Field(
        default="daily",
        example="daily",
        description="'daily' (next N days), 'monthly' (specific month), or 'yearly' (full year)"
    )
    
    # For daily calendar
    from_date: Optional[str] = Field(
        default=None,
        example="2026-04-15",
        description="Start date for daily calendar. Defaults to today."
    )
    days_ahead: int = Field(
        default=30,
        ge=7,
        le=365,
        description="Number of days to show (default 30)"
    )
    
    # For monthly/yearly calendar
    year: Optional[int] = Field(
        default=None,
        example=2026,
        description="Year for monthly/yearly calendar. Defaults to current year."
    )
    month: Optional[int] = Field(
        default=None,
        ge=1,
        le=12,
        example=4,
        description="Month (1-12) for monthly calendar. Defaults to current month."
    )


# ─────────────────────────────────────────────────────────────
# NEW v3.0 Schemas
# ─────────────────────────────────────────────────────────────

class ShadbalaInput(BaseModel):
    """Input for Shadbala (six-fold planetary strength) calculation."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")


class BhavaChalitInput(BaseModel):
    """Input for Bhava Chalit chart."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="lahiri")


class KPAnalysisInput(BaseModel):
    """Input for KP (Krishnamurti) system analysis."""
    name: str  = Field(...,  example="Himanshu")
    date: str  = Field(...,  example="1990-01-15")
    time: str  = Field(...,  example="10:30")
    place: str = Field(...,  example="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None)
    longitude: Optional[float] = Field(default=None)
    timezone_offset_minutes: Optional[int] = Field(default=None)
    ayanamsa: str = Field(default="krishnamurti")
    # Optional transit for ruling planets
    transit_date: Optional[str] = Field(default=None, example="2026-04-28")
    transit_time: Optional[str] = Field(default="09:15")


class PanchangInput(BaseModel):
    """Input for Panchang calculation."""
    date: str  = Field(...,  example="2026-04-28")
    time: str  = Field(default="09:15", example="09:15")
    place: str = Field(default="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None, example=19.076)
    longitude: Optional[float] = Field(default=None, example=72.8777)
    timezone_offset_minutes: int = Field(default=330)
    ayanamsa: str = Field(default="lahiri")


class PanchangCalendarInput(BaseModel):
    """Input for multi-day Panchang trading calendar."""
    start_date: str = Field(..., example="2026-04-01")
    days: int = Field(default=30, ge=7, le=365)
    place: str = Field(default="Mumbai, Maharashtra, India")
    latitude:  Optional[float] = Field(default=None, example=19.076)
    longitude: Optional[float] = Field(default=None, example=72.8777)
    timezone_offset_minutes: int = Field(default=330)
    ayanamsa: str = Field(default="lahiri")


class MarketDataInput(BaseModel):
    """Input for live market data."""
    indices: List[str] = Field(
        default=["NIFTY_50", "SENSEX", "BANK_NIFTY"],
        description="Index names: NIFTY_50, SENSEX, BANK_NIFTY, NIFTY_IT, etc."
    )


class BacktestInput(BaseModel):
    """Input for backtesting astrology signals against market data."""
    ticker: str = Field(default="NIFTY_50", example="NIFTY_50")
    start_date: str = Field(default="2023-01-01", example="2023-01-01")
    end_date: Optional[str] = Field(default=None, example="2026-04-28")
    signal_type: str = Field(
        default="composite",
        description="'moon_nakshatra', 'planetary_transits', or 'composite'"
    )
    ayanamsa: str = Field(default="lahiri")
